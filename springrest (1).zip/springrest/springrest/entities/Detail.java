package com.springrest.springrest.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Detail {

	@Id
	private long id;
	private String transDate;
	private long transAmount;
	private String transType;
	
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

	public long getTransAmount() {
		return transAmount;
	}

	public void setTransAmount(long transAmount) {
		this.transAmount = transAmount;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}



	@Override
	public String toString() {
		return "Detail [id=" + id + ", transDate=" + transDate + ", transAmount=" + transAmount + ", transType="
				+ transType + "]";
	}



	public Detail() {
		super();
		
	}



	public Detail(long id, String transDate, long transAmount, String transType) {
		super();
		this.id = id;
		this.transDate = transDate;
		this.transAmount = transAmount;
		this.transType = transType;
	}
	
	
	
}
