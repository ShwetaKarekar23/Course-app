package com.springrest.springrest.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties("hibernateLazyInitializer")
public class User {
	
	@Id
	private long accountId;
	private String name;
	private String accountType;
	private String dateOfOpening;
	private long openingBalance;
	
	@OneToMany(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "account_id")
	private List<Detail> details;

	
	
	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getDateOfOpening() {
		return dateOfOpening;
	}

	public void setDateOfOpening(String dateOfOpening) {
		this.dateOfOpening = dateOfOpening;
	}

	public long getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(long openingBalance) {
		this.openingBalance = openingBalance;
	}

	public List<Detail> getDetails() {
		return details;
	}

	public void setDetails(List<Detail> details) {
		this.details = details;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(long accountId, String name, String accountType, String dateOfOpening, long openingBalance,
			List<Detail> details) {
		super();
		this.accountId = accountId;
		this.name = name;
		this.accountType = accountType;
		this.dateOfOpening = dateOfOpening;
		this.openingBalance = openingBalance;
		this.details = details;
	}

	@Override
	public String toString() {
		return "User [accountId=" + accountId + ", name=" + name + ", accountType=" + accountType + ", dateOfOpening="
				+ dateOfOpening + ", openingBalance=" + openingBalance + ", details=" + details + "]";
	}
	
	
	

}
