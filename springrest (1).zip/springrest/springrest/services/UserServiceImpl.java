package com.springrest.springrest.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.dao.UserDao;
import com.springrest.springrest.entities.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	//List<User> list;
	
	public UserServiceImpl() {
		
		
	//	list=new ArrayList<>();
	//	list.add(new User(123,"rahul","saving","12-05-2021",500000));
	//	list.add(new User(143,"shweta","saving","11-05-2021",100000));
	}
	
	@Override
	public List<User> getUsers() {
		
		return userDao.findAll();
	}

	@Override
	public User getUser(long userId) {
//		User u=null;
//		for(User user:list) {
//			if(user.getId()==userId) {
//				u=user;
//				break;
//			}
//		}
		return userDao.getOne(userId);
	}

}
