package com.springrest.springrest.services;

import java.util.List;

import com.springrest.springrest.entities.Detail;

public interface DetailService {
	
public List<Detail> getDetail();
	
	public Detail getDetail(long detailId);

}
