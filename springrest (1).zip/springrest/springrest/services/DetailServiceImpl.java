package com.springrest.springrest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.springrest.dao.DetailDao;
import com.springrest.springrest.entities.Detail;

@Service
public class DetailServiceImpl implements DetailService {
	
	@Autowired
	private DetailDao detailDao;
	
	public DetailServiceImpl() {
		
		}
	

	@Override
	public Detail getDetail(long detailId) {

		return detailDao.getOne(detailId);
	}

	@Override
	public List<Detail> getDetail() {
		
		return detailDao.findAll();
	}

}
