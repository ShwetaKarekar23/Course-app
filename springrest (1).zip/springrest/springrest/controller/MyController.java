package com.springrest.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.springrest.springrest.entities.Detail;
import com.springrest.springrest.entities.User;
import com.springrest.springrest.services.DetailService;
import com.springrest.springrest.services.UserService;
@CrossOrigin
@RestController
public class MyController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private DetailService detailService;

	@GetMapping("/home")
	public String home() {
		return "Welcome to Bank Application";
	}
	
	@GetMapping("/users")
	public List<User> getUsers(){
		
		return this.userService.getUsers();
	}
	
	@GetMapping("/users/{userId}")
	public User getUser(@PathVariable String userId) {
		return this.userService.getUser(Long.parseLong(userId));
	}
	
	@GetMapping("/details")
	public List<Detail> getDetails(){
		
		return this.detailService.getDetail();
	}
	
	@GetMapping("/details/{detailId}")
	public Detail getDetail(@PathVariable String detailId) {
		return this.detailService.getDetail(Long.parseLong(detailId));
	}
}
